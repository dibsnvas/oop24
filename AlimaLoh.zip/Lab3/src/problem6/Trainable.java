package problem6;

public interface Trainable {
    void train();
}
