package problem6;

public interface Friendly {
    boolean isFriendly();
}
