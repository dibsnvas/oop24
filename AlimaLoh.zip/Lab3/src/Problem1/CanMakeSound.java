package Problem1;

public interface CanMakeSound {
	void makeSound();
}
