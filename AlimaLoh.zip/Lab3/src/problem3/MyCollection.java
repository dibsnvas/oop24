package problem3;

public class MyCollection {

}
