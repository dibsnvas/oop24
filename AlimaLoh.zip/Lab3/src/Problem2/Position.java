package Problem2;

public class Position {
	int x;
	int y;
	
	public Position() {
	}
	public Position(int x, int y) {
		this.x=x;
		this.y=y;
	}
	
}