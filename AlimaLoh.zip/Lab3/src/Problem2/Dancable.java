package Problem2;

public interface Dancable extends Moveable{
	void dance();
}
