package Problem2;

public interface Moveable {
	void move();
}
